/****************************************************************************
** Meta object code from reading C++ file 'myword.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MyselfWord/myword.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myword.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MyWord_t {
    QByteArrayData data[42];
    char stringdata0[367];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyWord_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyWord_t qt_meta_stringdata_MyWord = {
    {
QT_MOC_LITERAL(0, 0, 6), // "MyWord"
QT_MOC_LITERAL(1, 7, 7), // "fileNew"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 8), // "fileOpen"
QT_MOC_LITERAL(4, 25, 8), // "fileSave"
QT_MOC_LITERAL(5, 34, 10), // "fileSaveAs"
QT_MOC_LITERAL(6, 45, 9), // "filePrint"
QT_MOC_LITERAL(7, 55, 16), // "filePrintPreview"
QT_MOC_LITERAL(8, 72, 12), // "printPreview"
QT_MOC_LITERAL(9, 85, 9), // "QPrinter*"
QT_MOC_LITERAL(10, 95, 4), // "undo"
QT_MOC_LITERAL(11, 100, 4), // "redo"
QT_MOC_LITERAL(12, 105, 3), // "cut"
QT_MOC_LITERAL(13, 109, 4), // "copy"
QT_MOC_LITERAL(14, 114, 5), // "paste"
QT_MOC_LITERAL(15, 120, 5), // "about"
QT_MOC_LITERAL(16, 126, 8), // "textBold"
QT_MOC_LITERAL(17, 135, 10), // "textItalic"
QT_MOC_LITERAL(18, 146, 13), // "textUnderline"
QT_MOC_LITERAL(19, 160, 9), // "textAlign"
QT_MOC_LITERAL(20, 170, 8), // "QAction*"
QT_MOC_LITERAL(21, 179, 1), // "a"
QT_MOC_LITERAL(22, 181, 9), // "textStyle"
QT_MOC_LITERAL(23, 191, 10), // "styleIndex"
QT_MOC_LITERAL(24, 202, 10), // "textFamily"
QT_MOC_LITERAL(25, 213, 1), // "f"
QT_MOC_LITERAL(26, 215, 8), // "textSize"
QT_MOC_LITERAL(27, 224, 1), // "p"
QT_MOC_LITERAL(28, 226, 9), // "textColor"
QT_MOC_LITERAL(29, 236, 11), // "updateMenus"
QT_MOC_LITERAL(30, 248, 16), // "updateWindowMenu"
QT_MOC_LITERAL(31, 265, 5), // "count"
QT_MOC_LITERAL(32, 271, 4), // "find"
QT_MOC_LITERAL(33, 276, 8), // "Num0fstr"
QT_MOC_LITERAL(34, 285, 11), // "const char*"
QT_MOC_LITERAL(35, 297, 4), // "Mstr"
QT_MOC_LITERAL(36, 302, 6), // "substr"
QT_MOC_LITERAL(37, 309, 13), // "createMyChild"
QT_MOC_LITERAL(38, 323, 8), // "MyChild*"
QT_MOC_LITERAL(39, 332, 18), // "setActiveSubWindow"
QT_MOC_LITERAL(40, 351, 8), // "QWidget*"
QT_MOC_LITERAL(41, 360, 6) // "window"

    },
    "MyWord\0fileNew\0\0fileOpen\0fileSave\0"
    "fileSaveAs\0filePrint\0filePrintPreview\0"
    "printPreview\0QPrinter*\0undo\0redo\0cut\0"
    "copy\0paste\0about\0textBold\0textItalic\0"
    "textUnderline\0textAlign\0QAction*\0a\0"
    "textStyle\0styleIndex\0textFamily\0f\0"
    "textSize\0p\0textColor\0updateMenus\0"
    "updateWindowMenu\0count\0find\0Num0fstr\0"
    "const char*\0Mstr\0substr\0createMyChild\0"
    "MyChild*\0setActiveSubWindow\0QWidget*\0"
    "window"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyWord[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x08 /* Private */,
       3,    0,  155,    2, 0x08 /* Private */,
       4,    0,  156,    2, 0x08 /* Private */,
       5,    0,  157,    2, 0x08 /* Private */,
       6,    0,  158,    2, 0x08 /* Private */,
       7,    0,  159,    2, 0x08 /* Private */,
       8,    1,  160,    2, 0x08 /* Private */,
      10,    0,  163,    2, 0x08 /* Private */,
      11,    0,  164,    2, 0x08 /* Private */,
      12,    0,  165,    2, 0x08 /* Private */,
      13,    0,  166,    2, 0x08 /* Private */,
      14,    0,  167,    2, 0x08 /* Private */,
      15,    0,  168,    2, 0x08 /* Private */,
      16,    0,  169,    2, 0x08 /* Private */,
      17,    0,  170,    2, 0x08 /* Private */,
      18,    0,  171,    2, 0x08 /* Private */,
      19,    1,  172,    2, 0x08 /* Private */,
      22,    1,  175,    2, 0x08 /* Private */,
      24,    1,  178,    2, 0x08 /* Private */,
      26,    1,  181,    2, 0x08 /* Private */,
      28,    0,  184,    2, 0x08 /* Private */,
      29,    0,  185,    2, 0x08 /* Private */,
      30,    0,  186,    2, 0x08 /* Private */,
      31,    0,  187,    2, 0x08 /* Private */,
      32,    0,  188,    2, 0x08 /* Private */,
      33,    2,  189,    2, 0x08 /* Private */,
      37,    0,  194,    2, 0x08 /* Private */,
      39,    1,  195,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int, 0x80000000 | 34, 0x80000000 | 34,   35,   36,
    0x80000000 | 38,
    QMetaType::Void, 0x80000000 | 40,   41,

       0        // eod
};

void MyWord::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyWord *_t = static_cast<MyWord *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->fileNew(); break;
        case 1: _t->fileOpen(); break;
        case 2: _t->fileSave(); break;
        case 3: _t->fileSaveAs(); break;
        case 4: _t->filePrint(); break;
        case 5: _t->filePrintPreview(); break;
        case 6: _t->printPreview((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        case 7: _t->undo(); break;
        case 8: _t->redo(); break;
        case 9: _t->cut(); break;
        case 10: _t->copy(); break;
        case 11: _t->paste(); break;
        case 12: _t->about(); break;
        case 13: _t->textBold(); break;
        case 14: _t->textItalic(); break;
        case 15: _t->textUnderline(); break;
        case 16: _t->textAlign((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 17: _t->textStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->textFamily((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->textSize((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->textColor(); break;
        case 21: _t->updateMenus(); break;
        case 22: _t->updateWindowMenu(); break;
        case 23: _t->count(); break;
        case 24: _t->find(); break;
        case 25: { int _r = _t->Num0fstr((*reinterpret_cast< const char*(*)>(_a[1])),(*reinterpret_cast< const char*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 26: { MyChild* _r = _t->createMyChild();
            if (_a[0]) *reinterpret_cast< MyChild**>(_a[0]) = std::move(_r); }  break;
        case 27: _t->setActiveSubWindow((*reinterpret_cast< QWidget*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 27:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MyWord::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MyWord.data,
      qt_meta_data_MyWord,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MyWord::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyWord::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MyWord.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MyWord::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
